# walk

Walk — a terminal navigator; a `cd` and `ls` replacement.

Description

Walk lets you navigate the filesystem in a terminal interface and quickly change
directories. It provides an interactive view, preview pane and keyboard
shortcuts to make navigating and managing files comfortable.

Usage

Run `lk` to start the program. Use arrow keys or hjkl to move. Press `Enter` to
enter a directory and `Backspace` to go up. Press `Esc` or `q` to exit and change
into the selected directory, or `Ctrl+C` to exit without changing directories.

Key bindings

- arrows, hjkl: Move cursor
- shift + arrows: Jump to start/end
- Enter: Enter directory
- Backspace: Exit directory
- Space: Toggle preview
- Esc, q: Exit with cd
- Ctrl+C: Exit without cd
- /: Fuzzy search
- d, Delete: Delete file or directory (undo with u)
- y: Yank current dir
- .: Hide hidden files

Configuration

The program respects the following environment variables for user configuration:

- EDITOR or WALK_EDITOR: editor used for opening files
- WALK_OPEN_WITH: per-extension open commands
- WALK_REMOVE_CMD: command used to remove files instead of default rm
- WALK_MAIN_COLOR: main color used by the interface
- WALK_STATUS_BAR: expression to specify custom status bar

Flags

- --icons: Show icons
- --dir-only: Show dirs only
- --hide-hidden: Hide hidden files
- --preview: Start with preview mode on
- --with-border: Show border in preview mode
- --fuzzy: Start with fuzzy search on

For full usage examples and behavior, see STATUS_BAR.md for status bar configuration.

License

This project is provided under the terms of the MIT License. See LICENSE for
details.
