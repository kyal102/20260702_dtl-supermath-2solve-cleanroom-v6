#!/bin/sh
set -u
build_python_fallback() {
  py="$(command -v python3 || command -v python)"
  cat > executable <<EOF
#!/bin/sh
script_dir="\${0%/*}"
[ "\$script_dir" = "\$0" ] && script_dir=.
exec "$py" "\$script_dir/walk_impl.py" "\$@"
EOF
  chmod +x executable
}
if [ -f go.mod ] && [ -f main.go ] && command -v go >/dev/null 2>&1; then
  if [ -x ./build.sh ] && ./build.sh; then
    :
  elif [ -f ./build.sh ] && chmod +x ./build.sh && ./build.sh; then
    :
  elif go build -o executable .; then
    :
  else
    build_python_fallback
  fi
else
  build_python_fallback
fi
